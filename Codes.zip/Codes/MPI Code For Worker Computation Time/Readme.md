Here MPI codes are provided to find the worker computation time for different types of codes. You can see details in our paper here https://arxiv.org/abs/2012.06065. If you are using these codes for distributed matrix computations, please cite us-

Anindya Bijoy Das, and Aditya Ramamoorthy, “Coded sparse matrix computation schemes thatleverage partial stragglers,” preprint, 2020,[Online] Available: https://arxiv.org/abs/2012.06065.
